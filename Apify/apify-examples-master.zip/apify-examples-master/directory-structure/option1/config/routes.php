<?php
$routes[] = new Route('/', 
    array(
        'controller' => 'index', 
        'action'     => 'index'
    )
);

return $routes;
