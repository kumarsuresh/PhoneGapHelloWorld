Yii Documentation
=================

This directory contains framework documentation. Currently it's
"The Definitive Guide to Yii" and "The Yii Blog Tutorial".

You can point your webserver webroot to this directory and view documentation
offline. Currently it doesn't match what you're getting at the website in terms
of usability but we'll work on it.

If you want to participate in translating documentation, check
[Documentation translation guidelines](https://github.com/yiisoft/yii/wiki/Documentation-translation-guidelines)
and then get in touch with [translation team](https://github.com/yiisoft/yii/wiki/Translation-team)
for the language you're going to work on.