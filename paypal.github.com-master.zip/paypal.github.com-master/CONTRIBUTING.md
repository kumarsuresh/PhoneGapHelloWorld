### autoPopulate

Initial thoughts: We looked at using the github SDK, **but** since we have so many repos (eg: SDK's are not really relevant OSS projects)
this resulted in a very large list.

We settled on a curated list found in `projects.js`. The idea is to give the website maintainer a single point of editing,
without having to worry about html, etc.