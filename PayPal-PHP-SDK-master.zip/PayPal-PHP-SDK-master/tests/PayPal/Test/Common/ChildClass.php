<?php
namespace PayPal\Test\Common;

use PayPal\Common\PayPalModel;

class ChildClass extends SimpleClass
{

}
